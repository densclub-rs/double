---
style: double
status: release-candidate
submodule: machine-of-ideas
mindmap-plugin: basic
version: 0.2.1
---

# [Machine of Ideas](../../.double.md)

## [Entry Point](../skills.md)
- [SKILL](./SKILL.md)
