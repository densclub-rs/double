---
style: double
submodule: machine-of-ideas
status: release-candidate
mindmap-plugin: basic
version: 0.2.1
---

# [Machine of Ideas](../../.double.md)

## [Registries](../registries.md)
- [Agents Registry](./agents-registry.md)
- [Modes Registry](./modes-registry.md)
- [Roles Registry](./roles-registry.md)
- [Skills Registry](./skills-registry.md)
- [Workflows Registry](./workflows-registry.md)
