---
style: double
submodule: machine-of-ideas
status: release-candidate
mindmap-plugin: basic

version: 0.2.1
---

# [Machine of Ideas](../../.double.md)

## [Agents](../agents.md)
- [Idea Capture](./idea-capture/idea-capture.md)
- [Concept Extraction](./concept-extraction/concept-extraction.md)
- [Principle Synthesis](./principle-synthesis/principle-synthesis.md)
