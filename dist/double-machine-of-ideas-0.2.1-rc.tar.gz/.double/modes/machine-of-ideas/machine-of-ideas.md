---
style: double
submodule: machine-of-ideas
status: release-candidate
mindmap-plugin: basic
version: 0.2.1
---

# [Machine of Ideas](../../.double.md)

## [Modes](../modes.md)
- [Brainstorm](./brainstorm/brainstorm.md)
- [Explain](./explain/explain.md)
- [Strict Research](./strict-research/strict-research.md)
- [Validation](./validation/validation.md)
- [Editor](./editor/editor.md)
