---
style: double
submodule: machine-of-ideas
id: strict-research
kind: mode
status: release-candidate
user-selectable: true
class: cognitive
derived-from:
  - ideas/machine-of-ideas/directory-layout/directory-layout.md
version: 0.2.1
---

# Mode: Strict Research

## Purpose

Used when the agent should draw conclusions as strictly as possible and support them with arguments, sources, or research grounds.

## Behavioral Intent

- strengthen argumentative rigor
- reduce arbitrary interpretations
- increase the requirement for justified conclusions

## Output Expectation

The artifact or response should be more rigorous, analytical, and verifiable than in regular mode.
