---
style: double
submodule: machine-of-ideas
status: release-candidate
mindmap-plugin: basic
version: 0.2.1
---

# [System Prompts](../../../.double.md)

## [Machine of Ideas](../../prompts.md)
- [Idea Capture](./idea-capture.md)
- [Concept Extraction](./concept-extraction.md)
- [Principle Synthesis](./principle-synthesis.md)
