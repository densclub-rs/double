---
style: double
submodule: machine-of-ideas
status: release-candidate
mindmap-plugin: basic
version: 0.2.1
---

# [Machine of Ideas](../../.double.md)

## [Roles](../roles.md)
- [Idea Capture Role](./idea-capture-role.md)
- [Concept Extractor Role](./concept-extractor-role.md)
- [Principle Synthesizer Role](./principle-synthesizer-role.md)
